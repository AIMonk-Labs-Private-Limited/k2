## File description

<https://shields.io/> is used to create the following files:

- ./os.svg
- ./python_ge_3.6-blue.svg
- ./cuda_ge_10.1-orange.svg
- ./pytorch_ge_1.5.0-green.svg
