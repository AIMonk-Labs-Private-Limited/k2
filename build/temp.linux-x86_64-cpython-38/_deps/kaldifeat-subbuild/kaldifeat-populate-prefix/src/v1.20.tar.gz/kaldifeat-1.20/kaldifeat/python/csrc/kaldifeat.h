// kaldifeat/python/csrc/kaldifeat.h
//
// Copyright (c)  2021  Xiaomi Corporation (authors: Fangjun Kuang)

#ifndef KALDIFEAT_PYTHON_CSRC_KALDIFEAT_H_
#define KALDIFEAT_PYTHON_CSRC_KALDIFEAT_H_

#include "pybind11/pybind11.h"
#include "torch/torch.h"
namespace py = pybind11;

#endif  // KALDIFEAT_PYTHON_CSRC_KALDIFEAT_H_
